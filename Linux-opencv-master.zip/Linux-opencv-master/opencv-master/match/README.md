
## SIFT, SURF, ORB, FAST descriptors matching!


=>  match_brouteforce.cxx : Descriptors Matching using broute force method. it is worked with SIFT, SURF, ORB(provided by params)

=>  match_brouteforce_fast.cxx : Fast detecting + Surf descriptors!

=> SIFT_match.cpp : Extract SIFT descriptors and match two images by broute force, **Using ratio test and symmetric test , it is very effective!** 

=>  SIFT_match2.cpp : As above , but use Flann-based matcher (kd-tree) !