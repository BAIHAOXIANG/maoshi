
vonzhou@CHOWN:~/GitHub/opencv/image-search$ ./search ../Dataset/images/ukbench00132.jpg ../Dataset/images/
1: {ukbench00132.jpg, ukbench00132.jpg, 500, 500, 500, 1}

2: {ukbench00132.jpg, ukbench00133.jpg, 500, 487, 144, 0.170819}

3: {ukbench00132.jpg, ukbench00134.jpg, 500, 500, 98, 0.108647}

4: {ukbench00132.jpg, ukbench00135.jpg, 500, 500, 75, 0.0810811}

5: {ukbench00132.jpg, ukbench00298.jpg, 500, 500, 4, 0.00401606}

6: {ukbench00132.jpg, ukbench00186.jpg, 500, 500, 4, 0.00401606}

7: {ukbench00132.jpg, ukbench00238.jpg, 500, 500, 4, 0.00401606}

8: {ukbench00132.jpg, ukbench00146.jpg, 500, 500, 4, 0.00401606}

9: {ukbench00132.jpg, ukbench00245.jpg, 500, 500, 4, 0.00401606}

10: {ukbench00132.jpg, ukbench00171.jpg, 500, 500, 4, 0.00401606}

-----------------------------------------
1: {ukbench00132.jpg, ukbench00132.jpg, 1274, 1274, 1274, 1}

2: {ukbench00132.jpg, ukbench00133.jpg, 1274, 1832, 339, 0.122515}

3: {ukbench00132.jpg, ukbench00134.jpg, 1274, 1923, 268, 0.0914988}

4: {ukbench00132.jpg, ukbench00135.jpg, 1274, 736, 54, 0.0276074}

5: {ukbench00132.jpg, ukbench00151.jpg, 1274, 481, 11, 0.00630734}

6: {ukbench00132.jpg, ukbench00189.jpg, 1274, 379, 9, 0.00547445}

7: {ukbench00132.jpg, ukbench00289.jpg, 1274, 464, 9, 0.00520532}

8: {ukbench00132.jpg, ukbench00204.jpg, 1274, 432, 8, 0.00471143}

9: {ukbench00132.jpg, ukbench00293.jpg, 1274, 226, 7, 0.00468855}

10: {ukbench00132.jpg, ukbench00279.jpg, 1274, 887, 10, 0.004649}
