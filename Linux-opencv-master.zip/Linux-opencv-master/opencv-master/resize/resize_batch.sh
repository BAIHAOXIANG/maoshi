./resize  ../Dataset/image100/  0.95
./resize  ../Dataset/image100/  0.9
./resize  ../Dataset/image100/  0.85
./resize  ../Dataset/image100/  0.8
./resize  ../Dataset/image100/  0.75
./resize  ../Dataset/image100/  0.7
./resize  ../Dataset/image100/  0.65
./resize  ../Dataset/image100/  0.6
./resize  ../Dataset/image100/  0.55
./resize  ../Dataset/image100/  0.5
./resize  ../Dataset/image100/  0.45
./resize  ../Dataset/image100/  0.4
./resize  ../Dataset/image100/  0.35
./resize  ../Dataset/image100/  0.3
./resize  ../Dataset/image100/  0.25
./resize  ../Dataset/image100/  0.2

