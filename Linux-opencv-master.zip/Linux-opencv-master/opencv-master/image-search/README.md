### Search Top K images by the query image !


The log is:
```
Imageset/test_set/target12.jpg:0.5
Imageset/test_set/target16.jpg:0.468
Imageset/test_set/target13.jpg:0.45675
Imageset/test_set/target11.jpg:0.323375
Imageset/test_set/target14.jpg:0.303625
Imageset/test_set/target7.jpg:0.29425
Imageset/test_set/target15.jpg:0.293
Imageset/test_set/target17.jpg:0.285625
Imageset/test_set/target18.jpg:0.228
Imageset/test_set/target8.jpg:0.215839
Imageset/test_set/target2.jpg:0.205875
Imageset/test_set/target5.jpg:0.19475
Imageset/test_set/target3.jpg:0.174
Imageset/test_set/target1.jpg:0.1675
Imageset/test_set/target6.jpg:0.1305
Imageset/test_set/target9.jpg:0.107
Imageset/test_set/1037081.jpg:0.002875
Imageset/test_set/354862.jpg:0.0025
Imageset/test_set/1090837.jpg:0.002375
Imageset/test_set/105694.jpg:0.002375
Imageset/test_set/11280.jpg:0.002375
Imageset/test_set/99272.jpg:0.00225
Imageset/test_set/876487.jpg:0.00225
Imageset/test_set/1091396.jpg:0.00225
Imageset/test_set/1173229.jpg:0.00225
Imageset/test_set/97933.jpg:0.002125
Imageset/test_set/1004884.jpg:0.002125
Imageset/test_set/1154471.jpg:0.002125
Imageset/test_set/1114433.jpg:0.002125
Imageset/test_set/1181572.jpg:0.002125

```