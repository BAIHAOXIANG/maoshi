echo "Begin to testing 100.jpg...."
./search ../Dataset/Imageset/query_set/100.jpg ../Dataset/Imageset/test_set/






