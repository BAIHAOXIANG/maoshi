echo "Begin to testing 100.jpg...."
./search ../Dataset/Imageset/query_set/100.jpg ../Dataset/Imageset/test_set/

echo "Begin to testing 90.jpg...."
./search ../Dataset/Imageset/query_set/90.jpg ../Dataset/Imageset/test_set/

echo "Begin to testing 80.jpg...."
./search ../Dataset/Imageset/query_set/80.jpg ../Dataset/Imageset/test_set/

echo "Begin to testing 70.jpg...."
./search ../Dataset/Imageset/query_set/70.jpg ../Dataset/Imageset/test_set/

echo "Begin to testing 60.jpg...."
./search ../Dataset/Imageset/query_set/60.jpg ../Dataset/Imageset/test_set/

echo "Begin to testing 50.jpg...."
./search ../Dataset/Imageset/query_set/50.jpg ../Dataset/Imageset/test_set/

echo "Begin to testing 40.jpg...."
./search ../Dataset/Imageset/query_set/40.jpg ../Dataset/Imageset/test_set/

echo "Begin to testing 30.jpg...."
./search ../Dataset/Imageset/query_set/30.jpg ../Dataset/Imageset/test_set/

echo "Begin to testing 30-80.jpg...."
./search ../Dataset/Imageset/query_set/30-80.jpg ../Dataset/Imageset/test_set/

echo "Begin to testing 30-60.jpg...."
./search ../Dataset/Imageset/query_set/30-60.jpg ../Dataset/Imageset/test_set/

echo "Begin to testing 30-40.jpg...."
./search ../Dataset/Imageset/query_set/30-40.jpg ../Dataset/Imageset/test_set/

echo "Begin to testing 30-30.jpg...."
./search ../Dataset/Imageset/query_set/30-30.jpg ../Dataset/Imageset/test_set/




