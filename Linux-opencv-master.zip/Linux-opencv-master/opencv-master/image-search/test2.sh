echo "Begin to testing 100.jpg...."
./search ../Dataset/Imageset/query_set/100.jpg ../Dataset/Imageset/test_set/

echo "Begin to testing 90.jpg...."
./search ../Dataset/Imageset/query_set/90.jpg ../Dataset/Imageset/test_set/

echo "Begin to testing 80.jpg...."
./search ../Dataset/Imageset/query_set/80.jpg ../Dataset/Imageset/test_set/

echo "Begin to testing 70.jpg...."
./search ../Dataset/Imageset/query_set/70.jpg ../Dataset/Imageset/test_set/


